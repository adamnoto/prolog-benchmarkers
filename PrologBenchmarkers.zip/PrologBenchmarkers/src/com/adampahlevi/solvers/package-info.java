/**
 * 
 */
/**
 * @author adampahlevi
 * @since Nov 23, 2013
 */
package com.adampahlevi.solvers;